# cardano-base

This package includes:

  - Binary serialisation and deserialisation for Cardano, built on top of the [cborg] package

[cborg]: https://hackage.haskell.org/package/cborg
