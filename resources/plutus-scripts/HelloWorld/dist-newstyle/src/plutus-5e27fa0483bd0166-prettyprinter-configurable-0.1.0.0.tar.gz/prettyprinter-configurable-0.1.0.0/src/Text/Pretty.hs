-- | A module alias for way too verbose "Data.Text.Prettyprint.Doc".
module Text.Pretty
    ( module Export
    ) where

import           Data.Text.Prettyprint.Doc as Export
