# Revision history for cardano-prelude

## 0.1.0.0 -- 2018-09-24

* First version. Released on an unsuspecting world.
